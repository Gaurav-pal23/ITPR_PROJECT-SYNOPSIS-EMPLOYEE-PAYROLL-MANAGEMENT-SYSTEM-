package ui;
import service.PayrollCalculator;
import java.util.Scanner;

public class MainMenu {
    public static void show() {
        Scanner sc = new Scanner(System.in);
        PayrollCalculator pc = new PayrollCalculator();

        System.out.print("Enter Basic Salary: ");
        double basic = sc.nextDouble();

        System.out.print("Enter Present Days: ");
        int days = sc.nextInt();

        double net = pc.calculateNetSalary(basic, 2000, 1500, 1000, 1800, 2000, days);

        System.out.println("----- PAYSLIP -----");
        System.out.println("Net Salary = " + net);
        System.out.println("-------------------");
    }
}
