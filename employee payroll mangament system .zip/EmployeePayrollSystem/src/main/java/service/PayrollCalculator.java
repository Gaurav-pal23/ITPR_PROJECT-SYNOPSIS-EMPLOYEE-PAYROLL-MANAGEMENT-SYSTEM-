package service;

public class PayrollCalculator {
    public double calculateNetSalary(double basic, double hra, double da, double ta,
                                     double tax, double bonus, int presentDays) {
        double gross = basic + hra + da + ta + bonus;
        if (presentDays < 20) {
            gross -= 1000;
        }
        return gross - tax;
    }
}
