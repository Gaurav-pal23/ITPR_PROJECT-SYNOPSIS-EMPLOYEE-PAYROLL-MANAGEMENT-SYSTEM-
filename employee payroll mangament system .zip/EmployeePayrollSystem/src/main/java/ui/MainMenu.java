package ui;

import java.util.Scanner;
import service.PayrollCalculator;

public class MainMenu {

    public static void show() {
        Scanner sc = new Scanner(System.in);
        PayrollCalculator pc = new PayrollCalculator();

        int choice;

        do {
            System.out.println("\n===== PAYROLL MANAGEMENT SYSTEM =====");
            System.out.println("1. Generate Payslip");
            System.out.println("2. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Basic Salary: ");
                    double basic = sc.nextDouble();

                    System.out.print("Enter Present Days: ");
                    int days = sc.nextInt();

                    double net = pc.calculateNetSalary(
                            basic,
                            2000,   // HRA
                            1500,   // DA
                            1000,   // TA
                            1800,   // Medical
                            2000,   // Other Allowance
                            days
                    );

                    System.out.println("------ PAYSLIP ------");
                    System.out.println("Net Salary = " + net);
                    System.out.println("---------------------");
                    break;

                case 2:
                    System.out.println("Thank you! Exiting system.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 2);

        sc.close();
    }
}
