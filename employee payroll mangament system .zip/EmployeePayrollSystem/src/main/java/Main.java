import ui.MainMenu;

public class Main {
    public static void main(String[] args) {
        MainMenu.show();
    }
}
