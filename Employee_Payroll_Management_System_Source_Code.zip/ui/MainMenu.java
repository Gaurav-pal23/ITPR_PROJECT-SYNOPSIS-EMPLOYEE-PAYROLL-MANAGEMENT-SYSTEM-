package ui;
import service.PayrollCalculator;
import java.util.Scanner;

public class MainMenu {
    public static void show() {
        Scanner sc = new Scanner(System.in);
        PayrollCalculator pc = new PayrollCalculator();

        System.out.print("Enter Basic Salary: ");
        double basic = sc.nextDouble();

        double net = pc.calculateNetSalary(basic, 2000, 1500, 1000, 1800);
        System.out.println("Net Salary = " + net);
    }
}
