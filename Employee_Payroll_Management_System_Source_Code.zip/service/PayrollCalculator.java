package service;

public class PayrollCalculator {
    public double calculateNetSalary(double basic, double hra, double da, double ta, double tax) {
        double gross = basic + hra + da + ta;
        return gross - tax;
    }
}
