package model;

public class Employee {
    public int empId;
    public String name;
    public double basicSalary;

    public Employee(int empId, String name, double basicSalary) {
        this.empId = empId;
        this.name = name;
        this.basicSalary = basicSalary;
    }
}
